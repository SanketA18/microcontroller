
#include<p18F4550.h>
#include<stdio.h>

void InitUART()
{
  TRISCbits.RC6 = 0;                        //TX pin set as output
  TRISCbits.RC7 = 1;                        //RX pin set as input

  SPBRG = 77;

  TXSTA = 0b00100000;                       
  RCSTA = 0b10010000;
}

void SendChar(unsigned char data)
{
    while(TXIF == 0);             
    TXREG = data;                 
}

unsigned char GetChar(void)
{
    while(!RCIF);                 
    return RCREG;                 
}

void main(void)
{
    unsigned char key;
    InitUART();

    while(1)
    {
        key=GetChar();
        SendChar(key);
    }
}