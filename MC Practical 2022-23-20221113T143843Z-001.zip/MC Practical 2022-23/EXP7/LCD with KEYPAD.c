
#include <stdio.h>

#include <stdlib.h>

#include<pic18f4550.h>


#define RS LATCbits.LATC0

#define E LATCbits.LATC1

#define LCDPORT LATB

#define R1 LATDbits.LATD0

#define R2 LATDbits.LATD1

#define R3 LATDbits.LATD2

#define R4 LATDbits.LATD3

#define C1 PORTDbits.RD4

#define C2 PORTDbits.RD5

#define C3 PORTDbits.RD6

#define C4 PORTDbits.RD7


void delay()

{
 
   for(int i=0; i<30000; i++)
 
   {
    
}

}


void sendCommand(unsigned char command)

{
    
LCDPORT=command;
    
RS=0;

delay();
   
 E=1;
   
 delay();
   
 E=0;
    
delay();

}

void sendData(unsigned char data)

{
  
  LCDPORT=data;
    
RS=1;
   
 delay();
  
  E=1;
   
 delay();
  
  E=0;
   
 delay();

}


unsigned char keypad_read(void)

{
	
R1 = 0;
	
R2 = 1;
	
R3 = 1;
	
R4 = 1;
	
delay();
	
if (C1 == 0) return '1';		
	
if (C2 == 0) return '2';		
	
if (C3 == 0) return '3';		
	
if (C4 == 0) return 'A';		

	
R1 = 1;		
	
R2 = 0;
	
R3 = 1;

	
R4 = 1;
	
delay();
	
if (C1 == 0) return '4';
	
if (C2 == 0) return '5';
	
if (C3 == 0) return '6';
	
if (C4 == 0) return 'B';

	
R1 = 1;		
	
R2 = 1;

R3 = 0;

	
R4 = 1;

	delay();
	
if (C1 == 0) return '7';
	
if (C2 == 0) return '8';		
	
if (C3 == 0) return '9';		
	
if (C4 == 0) return 'C';		


        R1 = 1;		
	
R2 = 1;

	R3 = 1;

	R4 = 0;
	
delay();
	
if (C1 == 0) return '0';		
	
if (C2 == 0) return 'D';		
	
if (C3 == 0) return 'E';		
	
if (C4 == 0) return 'F';		
        
	
return 0xFF;				

}

unsigned char keypad_wait()

{
    
unsigned char key_press = 0xFF;
	
do
        
{
	
	key_press = keypad_read();

	}
	while (key_press == 0xFF);

        while (keypad_read() != 0xFF);

        return key_press;

}

void main()

{
    
TRISB=0x00;
    
TRISD=0xF0;
    
TRISCbits.RC0=0;
    
TRISCbits.RC1=0;
    
unsigned char key_get;
    
sendCommand(0x38);
    
sendCommand(0x01);
    
sendCommand(0x0F);
    
sendCommand(0x06);
   
 sendCommand(0x80);
  
  while(1)
  
  {
     
   key_get = keypad_wait();
   
     sendData(key_get);
 
   }

}